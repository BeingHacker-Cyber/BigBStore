import { Product } from '@/lib/types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Premium Wireless Headphones',
    price: 15999,
    description: 'High-quality wireless headphones with noise cancellation and premium sound quality.',
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Electronics'
  },
  {
    id: '2',
    name: 'Smart Fitness Watch',
    price: 12999,
    description: 'Advanced fitness tracking with heart rate monitor, GPS, and smartphone connectivity.',
    image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Electronics'
  },
  {
    id: '3',
    name: 'Leather Laptop Bag',
    price: 8999,
    description: 'Premium leather laptop bag with multiple compartments and professional design.',
    image: 'https://images.pexels.com/photos/2905238/pexels-photo-2905238.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Accessories'
  },
  {
    id: '4',
    name: 'Wireless Phone Charger',
    price: 3999,
    description: 'Fast wireless charging pad compatible with all Qi-enabled devices.',
    image: 'https://images.pexels.com/photos/4526943/pexels-photo-4526943.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Electronics'
  },
  {
    id: '5',
    name: 'Premium Coffee Mug Set',
    price: 2999,
    description: 'Set of 4 ceramic coffee mugs with elegant design and comfortable grip.',
    image: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Home'
  },
  {
    id: '6',
    name: 'Bluetooth Speaker',
    price: 6999,
    description: 'Portable Bluetooth speaker with powerful bass and 12-hour battery life.',
    image: 'https://images.pexels.com/photos/1649771/pexels-photo-1649771.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Electronics'
  },
  {
    id: '7',
    name: 'Designer Sunglasses',
    price: 4999,
    description: 'Stylish sunglasses with UV protection and premium frame construction.',
    image: 'https://images.pexels.com/photos/701877/pexels-photo-701877.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Fashion'
  },
  {
    id: '8',
    name: 'Smartphone Stand',
    price: 1999,
    description: 'Adjustable smartphone stand for desk use with anti-slip base.',
    image: 'https://images.pexels.com/photos/4526943/pexels-photo-4526943.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Accessories'
  }
];