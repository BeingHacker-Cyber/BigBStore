'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AuthModal } from '@/components/auth/AuthModal';
import { ProfileModal } from '@/components/profile/ProfileModal';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { CheckoutModal } from '@/components/checkout/CheckoutModal';
import { ProductGrid } from '@/components/products/ProductGrid';
import { OrderHistory } from '@/components/orders/OrderHistory';
import { useAuth } from '@/hooks/useAuth';
import { useCart } from '@/hooks/useCart';
import { Store, User, History, LogOut } from 'lucide-react';
import { toast } from 'sonner';

export default function Home() {
  const { user, logout, isProfileComplete } = useAuth();
  const { getCartItemsCount } = useCart();
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [profileModalOpen, setProfileModalOpen] = useState(false);
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);

  const handleCheckout = () => {
    // Check if cart has items
    if (getCartItemsCount() === 0) {
      toast.error('Your cart is empty. Add some products first!', { duration: 3000 });
      return;
    }

    if (!user) {
      toast.info('Please sign in to continue with checkout', { duration: 3000 });
      setAuthModalOpen(true);
      return;
    }

    if (!isProfileComplete()) {
      toast.info('Please complete your profile to continue', { duration: 3000 });
      setProfileModalOpen(true);
      return;
    }

    setCheckoutModalOpen(true);
  };

  const handleLogout = async () => {
    await logout();
    toast.success('Logged out successfully', { duration: 2000 });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <Store className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-gray-900">BigB Store.pk</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <CartDrawer onCheckout={handleCheckout} />
              
              {user ? (
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setProfileModalOpen(true)}
                  >
                    <User className="h-4 w-4 mr-2" />
                    {user.name || 'Profile'}
                  </Button>
                  <Button variant="ghost" size="sm" onClick={handleLogout}>
                    <LogOut className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <Button onClick={() => setAuthModalOpen(true)}>
                  Sign In
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {user ? (
          <Tabs defaultValue="products" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2 max-w-md">
              <TabsTrigger value="products">
                <Store className="h-4 w-4 mr-2" />
                Products
              </TabsTrigger>
              <TabsTrigger value="orders">
                <History className="h-4 w-4 mr-2" />
                Orders
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="products">
              <div className="space-y-6">
                <div className="text-center">
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">
                    Welcome to BigB Store
                  </h2>
                  <p className="text-gray-600 max-w-2xl mx-auto">
                    Discover amazing products at unbeatable prices. Shop with confidence and enjoy fast delivery across Pakistan.
                  </p>
                </div>
                <ProductGrid />
              </div>
            </TabsContent>
            
            <TabsContent value="orders">
              <div className="space-y-6">
                <h2 className="text-2xl font-bold text-gray-900">Order History</h2>
                <OrderHistory />
              </div>
            </TabsContent>
          </Tabs>
        ) : (
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">
                Welcome to BigB Store
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto mb-8">
                Discover amazing products at unbeatable prices. Sign in to start shopping and enjoy fast delivery across Pakistan.
              </p>
              <Button onClick={() => setAuthModalOpen(true)} size="lg">
                Sign In to Shop
              </Button>
            </div>
            <ProductGrid />
          </div>
        )}
      </main>

      {/* Modals */}
      <AuthModal isOpen={authModalOpen} onClose={() => setAuthModalOpen(false)} />
      <ProfileModal 
        isOpen={profileModalOpen} 
        onClose={() => setProfileModalOpen(false)}
        onComplete={() => setCheckoutModalOpen(true)}
      />
      <CheckoutModal 
        isOpen={checkoutModalOpen} 
        onClose={() => setCheckoutModalOpen(false)} 
      />
    </div>
  );
}