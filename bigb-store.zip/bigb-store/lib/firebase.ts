import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  // You need to replace these with your actual Firebase project credentials
  // Get them from: https://console.firebase.google.com -> Project Settings -> General -> Your apps
  apiKey: "AIzaSyBvOQHC2jh-de5ELVyoe2FuFyreVlQjZAQ",
  authDomain: "bigb-store-demo.firebaseapp.com",
  projectId: "bigb-store-demo",
  storageBucket: "bigb-store-demo.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:0123456789abcdef"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();