export interface User {
  uid: string;
  email: string;
  name?: string;
  phone?: string;
  address?: string;
  profilePicture?: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
  category: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  userUid: string;
  userName: string;
  userPhone: string;
  userAddress: string;
  items: CartItem[];
  total: number;
  paymentMethod: 'easypaisa' | 'jazzcash' | 'bank';
  timestamp: Date;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered';
}

export interface UserProfile {
  name: string;
  phone: string;
  address: string;
}