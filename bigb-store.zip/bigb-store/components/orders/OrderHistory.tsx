'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/useAuth';
import { Order } from '@/lib/types';
import { Package, Clock, CheckCircle, Truck } from 'lucide-react';

export const OrderHistory = () => {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // In a real app, you would fetch orders from your backend
    // For demo purposes, we'll use mock data
    const mockOrders: Order[] = [
      {
        id: 'ORDER-1704067200000',
        userUid: user?.uid || '',
        userName: user?.name || '',
        userPhone: user?.phone || '',
        userAddress: user?.address || '',
        items: [
          {
            product: {
              id: '1',
              name: 'Premium Wireless Headphones',
              price: 15999,
              description: 'High-quality wireless headphones',
              image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg',
              category: 'Electronics'
            },
            quantity: 1
          }
        ],
        total: 15999,
        paymentMethod: 'easypaisa',
        timestamp: new Date('2024-01-01'),
        status: 'delivered'
      },
      {
        id: 'ORDER-1704153600000',
        userUid: user?.uid || '',
        userName: user?.name || '',
        userPhone: user?.phone || '',
        userAddress: user?.address || '',
        items: [
          {
            product: {
              id: '2',
              name: 'Smart Fitness Watch',
              price: 12999,
              description: 'Advanced fitness tracking',
              image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg',
              category: 'Electronics'
            },
            quantity: 1
          }
        ],
        total: 12999,
        paymentMethod: 'jazzcash',
        timestamp: new Date('2024-01-02'),
        status: 'shipped'
      }
    ];

    setTimeout(() => {
      setOrders(mockOrders);
      setLoading(false);
    }, 1000);
  }, [user]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-PK', {
      style: 'currency',
      currency: 'PKR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  const getStatusIcon = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-4 w-4" />;
      case 'confirmed':
        return <CheckCircle className="h-4 w-4" />;
      case 'shipped':
        return <Truck className="h-4 w-4" />;
      case 'delivered':
        return <Package className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'confirmed':
        return 'bg-blue-100 text-blue-800';
      case 'shipped':
        return 'bg-purple-100 text-purple-800';
      case 'delivered':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map(i => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
              <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
              <div className="h-3 bg-gray-200 rounded w-1/3"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">No orders found</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {orders.map(order => (
        <Card key={order.id}>
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-lg">Order #{order.id}</CardTitle>
                <p className="text-sm text-gray-500">
                  {order.timestamp.toLocaleDateString('en-PK', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </p>
              </div>
              <Badge className={`${getStatusColor(order.status)} flex items-center gap-1`}>
                {getStatusIcon(order.status)}
                {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
              </Badge>
            </div>
          </CardHeader>
          
          <CardContent>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">Items:</h4>
                <div className="space-y-2">
                  {order.items.map((item, index) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span>{item.product.name} x {item.quantity}</span>
                      <span>{formatPrice(item.product.price * item.quantity)}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex justify-between items-center pt-2 border-t">
                <div className="text-sm">
                  <span className="font-medium">Payment: </span>
                  <span className="capitalize">{order.paymentMethod}</span>
                </div>
                <div className="font-semibold">
                  Total: {formatPrice(order.total)}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};