'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/hooks/useAuth';
import { useCart } from '@/hooks/useCart';
import { CreditCard, Smartphone, Building, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CheckoutModal = ({ isOpen, onClose }: CheckoutModalProps) => {
  const { user } = useAuth();
  const { cart, getCartTotal, clearCart } = useCart();
  const [paymentMethod, setPaymentMethod] = useState<'easypaisa' | 'jazzcash' | 'bank'>('easypaisa');
  const [loading, setLoading] = useState(false);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-PK', {
      style: 'currency',
      currency: 'PKR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  const submitOrder = async () => {
    if (!user) return;
    
    setLoading(true);
    
    const orderData = {
      orderId: `ORDER-${Date.now()}`,
      userUid: user.uid,
      userName: user.name,
      userPhone: user.phone,
      userAddress: user.address,
      items: cart.map(item => ({
        productId: item.product.id,
        productName: item.product.name,
        price: item.product.price,
        quantity: item.quantity,
        total: item.product.price * item.quantity
      })),
      total: getCartTotal(),
      paymentMethod,
      timestamp: new Date().toISOString(),
      status: 'pending'
    };

    try {
      const webhookUrl = 'https://script.google.com/macros/s/AKfycbzwouPTFU3vuP28vy7v3qYdkQ9lzQZ61etJ7wbBxkluwaw_a5EmTWjHBXma1zJGyGso/exec';
      
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(orderData),
      });

      if (response.ok) {
        toast.success('Order placed successfully! We will contact you soon.');
        clearCart();
        onClose();
      } else {
        throw new Error('Failed to submit order');
      }
    } catch (error) {
      toast.error('Failed to place order. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center text-2xl font-bold">Checkout</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="space-y-4">
            <h3 className="font-semibold">Order Summary</h3>
            <div className="space-y-2">
              {cart.map((item) => (
                <div key={item.product.id} className="flex justify-between text-sm">
                  <span>{item.product.name} x {item.quantity}</span>
                  <span>{formatPrice(item.product.price * item.quantity)}</span>
                </div>
              ))}
            </div>
            <div className="border-t pt-2 flex justify-between font-semibold">
              <span>Total:</span>
              <span>{formatPrice(getCartTotal())}</span>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="font-semibold">Delivery Information</h3>
            <div className="text-sm space-y-1">
              <p><strong>Name:</strong> {user?.name}</p>
              <p><strong>Phone:</strong> {user?.phone}</p>
              <p><strong>Address:</strong> {user?.address}</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="font-semibold">Payment Method</h3>
            <RadioGroup value={paymentMethod} onValueChange={(value: any) => setPaymentMethod(value)}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="easypaisa" id="easypaisa" />
                <Label htmlFor="easypaisa" className="flex items-center space-x-2 cursor-pointer">
                  <Smartphone className="h-4 w-4" />
                  <span>Easypaisa</span>
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="jazzcash" id="jazzcash" />
                <Label htmlFor="jazzcash" className="flex items-center space-x-2 cursor-pointer">
                  <CreditCard className="h-4 w-4" />
                  <span>JazzCash</span>
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="bank" id="bank" />
                <Label htmlFor="bank" className="flex items-center space-x-2 cursor-pointer">
                  <Building className="h-4 w-4" />
                  <span>Bank Transfer</span>
                </Label>
              </div>
            </RadioGroup>
          </div>
          
          <Button onClick={submitOrder} className="w-full" size="lg" disabled={loading}>
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Place Order
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};